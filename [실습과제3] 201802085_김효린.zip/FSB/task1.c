#include<stdio.h>
int main(){
	int a=10;
	int b=20;
	printf("A:%d, B:%d and B's address: %08x\n",a,b,&b);
	return 0;
}

