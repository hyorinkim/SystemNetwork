int main(){
	system("/bin/sh");
	return 0;
}
